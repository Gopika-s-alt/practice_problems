package inheritance_vehicle;

public class Car extends Vehicle{
	Car(String brand, int speed){
		super.brand=brand;
		super.speed=speed;
		System.out.println(brand+" "+speed);
		}
	public void openTrunk(){
		System.out.println("Trunk opened");
	}
}
