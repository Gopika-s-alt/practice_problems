package inheritance_vehicle;

public class Bike extends Vehicle{
	Bike(String brand, int speed){
		super.brand=brand;
		super.speed=speed;
		System.out.println(brand+" "+speed);
		}
	public void kickStart(){
		System.out.println("Bike kickstarted");
	}
	public static void main(String[]args){
	Car c =new Car("tata",120);
	c.start();
	c.openTrunk();
	c.stop();
	Bike b=new Bike("maruti",70);
	b.start();
	b.kickStart();
	b.stop();
	}	
}

