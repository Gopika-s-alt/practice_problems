package abstraction_shape;

public class Rectangle extends Shape{
	double len,breadth;
	Rectangle(double len,double breadth){
		this.len=len;
		this.breadth=breadth;
		shapeName="rectangle";
	}
	public double calculateArea() {
		return len*breadth;
	}
}
