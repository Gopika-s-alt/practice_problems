package encapsulation_bank_mgmt;

public class BankAccount {
	private int accountNumber;
	private int balance;
	public void setBalance(int accountNumber,int balance) {
		this.accountNumber=accountNumber;
		this.balance=balance;
	}
	public void deposit(int amount) {
		if(amount>0) {
			balance+=amount;
			System.out.println("Your balance is: "+balance);
		}
		else {
			System.out.println("Enter valid amount(>0)");
		}
	}	
	public void withdraw(int amount) {
		if(amount<balance) {
			balance-=amount;
			System.out.println("Your current balance: "+balance);
		}
		else {
			System.out.println("Insufficient balance");
		}
	}
	public void getBalance() {
		System.out.println("account number: "+accountNumber);
		System.out.println("Balance= "+balance);
	}
	public static void main(String[] args) {
		BankAccount b=new BankAccount();
		b.setBalance(1234, 20000);
		b.deposit(1000);
		b.withdraw(500);
		b.getBalance();
		b.withdraw(30000);
	}

}
