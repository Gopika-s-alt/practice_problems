package statickeyword;

public class Employee {
	static String companyName = "ABC";
	static int employeeCount = 0;
	int employeeId;
	String employeeName;
	Employee(int eId,String name) {
		employeeId=eId;
		employeeName = name;
		employeeCount++;
	}
	static int getEmployeeCount() {
	    System.out.println("Total number of employees: "+employeeCount);
	    return employeeCount;
	    }
	void displayEmployee() {
		System.out.println("Company Name: " + companyName);
	    System.out.println("Employee ID: " + employeeId);
	    System.out.println("Employee Name: " + employeeName);
	 }
	public static void main(String[] args) {
		Employee e1 = new Employee(101,"Ananya");
		e1.displayEmployee();
	    Employee e2 = new Employee(102,"Anu");
	    e2.displayEmployee();
	  } 
}
