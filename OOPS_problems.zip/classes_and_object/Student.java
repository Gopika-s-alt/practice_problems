package classes_and_object;

public class Student {
	String name;
	int rollNumber;
	int marks;
	public void setDetails(String name, int rollNumber, int marks){
		this.name=name;
		this.rollNumber=rollNumber;
		this.marks=marks;
	}
	public void displayDetails() {
		System.out.println("Name: "+name);
		System.out.println("Roll NUmber: "+rollNumber);
		System.out.println("Marks: "+marks);
	}
	public boolean isPassed() {
		if(marks>=40) {
			return true;
		}
		else {
			return false;
		}
	}

	public static void main(String[] args) {
		Student s=new Student();
		s.setDetails("Amirtha",17,75);
		s.displayDetails();
		System.out.println("Passed: "+s.isPassed());
		Student s1=new Student();
		s1.setDetails("Varshini",107,79);
		s1.displayDetails();
		System.out.println("Passed: "+s1.isPassed());
		Student s2=new Student();
		s2.setDetails("Ananya", 302, 39);
		s2.displayDetails();
		System.out.println("Passed: "+s2.isPassed());
	}
}
