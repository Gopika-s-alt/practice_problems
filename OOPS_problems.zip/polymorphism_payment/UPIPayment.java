package polymorphism_payment;

public class UPIPayment extends Payment{
	public void pay(int amount) {
		System.out.println(amount+" paid using UPI");
	}
}
