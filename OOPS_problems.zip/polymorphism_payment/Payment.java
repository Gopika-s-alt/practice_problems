package polymorphism_payment;

public class Payment {
	public void pay(int amount) {
		System.out.println("Generic payment method");
	}
	public static void main(String[] args) {
		Payment p;
		p=new Payment();
		p.pay(1000);
		p=new CreditCardPayment();
		p.pay(2000);
		p=new UPIPayment();
		p.pay(100);
	}

}
