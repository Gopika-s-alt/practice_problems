package polymorphism_payment;

public class CreditCardPayment extends Payment {
	public void pay(int amount) {
		System.out.println(amount+" paid using credit card");
	}
}
